#!/usr/bin/bash

docker build -t linux-dev-base:base .
